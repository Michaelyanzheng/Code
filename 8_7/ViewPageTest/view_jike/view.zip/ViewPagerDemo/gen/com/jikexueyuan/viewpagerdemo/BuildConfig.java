/** Automatically generated file. DO NOT MODIFY */
package com.jikexueyuan.viewpagerdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}